class FeatureExtractor:
    def extract_features(self, state, action):
        abstract
