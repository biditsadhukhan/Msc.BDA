class PotentialFunction:
    def get_potential(self, state):
        abstract
