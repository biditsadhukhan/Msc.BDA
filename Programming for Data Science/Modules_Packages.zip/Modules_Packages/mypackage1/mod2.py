__all__ = ['a','b','c','e','_f','f1']

a = 12
b = 13
c = 14
_d = 15
e = 16
_f = 17
g = 18



def f1(x):
	return x+3

def f2():
	print("this is f2 function in mod2")

def f3():
	print("this is f3 function in mod2")