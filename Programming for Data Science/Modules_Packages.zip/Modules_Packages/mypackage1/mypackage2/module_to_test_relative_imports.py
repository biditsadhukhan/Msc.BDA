from .. import mod1

print(mod1.a)
print("this module does a relative import")