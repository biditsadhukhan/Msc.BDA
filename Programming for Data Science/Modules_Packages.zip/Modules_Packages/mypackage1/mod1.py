a = 11
b = 12
def f1(x):
	return x+2

def f2():
	print("this is f2 function in mod1")

if __name__ == "__main__":
	f2()
	print('this block will execute only if this module is the driver code')