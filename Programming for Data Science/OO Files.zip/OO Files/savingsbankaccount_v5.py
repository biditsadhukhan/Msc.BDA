#import the bankaccount.py module to access the base class definitions
import bankaccount as ba

class SavingsBankAccount(ba.BankAccount):
	"""
	sub class for savings bank accounts with a constructor which refers to the 
	base class constructor which is delegated the initialization duty, and overrides 2
	base class methods and extends the functionality of the base class with a new method and
	also makes the instances of the class callable - version 5

	"""


	"""savings bank interest rate to be applied (in %) - class variable shared by all instances"""
	savings_bank_interest_rate = 7		

	"""the account type for SavingsBankAccount class - class variable"""
	account_type = "savings"

	"""override base class method to initialize the object with a custom initial state"""
	def __init__(self, account_no, name, initial_balance):
		"""
		create a new proper savings bank account which has 1 new attribute called savings bank interest.
		
		The initial balance is not zero.

		savings_bank_interest		the savings bank interest earned
		"""
			
		super().__init__(account_no,name,initial_balance)	#usually the first statement in the constructor
		
		#instance variables given below unique to each instance
		self._savings_bank_interest = 0	

	
	def compute_interest(self):
		"""
		extends the functionality of the base class by adding a new method not existent in the base class
		it computes the savings bank account interest
		"""
		
		self._savings_bank_interest += round((SavingsBankAccount.savings_bank_interest_rate / 100) * self._initial_balance,2)
		print("computed interest>>>>>")

	
	def __str__(self):
		"""overrides the super class (base class) __str__ method to include the interest amount"""
	
		return "name {} account no. {} balance {} interest {}".format(self.get_name(), self._account_no, 
		self.get_initial_balance(), self._savings_bank_interest)

	def __call__(self):
		self.compute_interest()


#you can import this module savingsbankaccount_v4 from a python terminal and execute the mymain method as below:
#import savingsbankaccount_v4
#savingsbankaccount_v4.mymain()
	
def mymain():
	accounts = []
	account1 = SavingsBankAccount(1000,'rajeev',200)
	account2 = SavingsBankAccount(1001,'sanjeev',100)
	accounts.append(account1)
	accounts.append(account2)
	for i in accounts:
		print("name %s account no. %d balance %d" % (i.get_name(), i._account_no, i.get_initial_balance()))
	
	#accessing the class variables
	print("---")
	print(f"account type: {account1.account_type} and interest rate: {account1.savings_bank_interest_rate}")
	print(f"account type: {SavingsBankAccount.account_type} and interest rate: {account1.savings_bank_interest_rate}")
	print("----")

	#invoking the __str__ method of the object
	for i in accounts:
		print(i)

	#invoking the __iter__ and __next__ methods of the object
	for j in account1:
		print(j)
	
	#compute interest for each account
	for i in accounts:
		i.compute_interest()
	
	print("----")
	#display the new details of the bank accounts
	for i in accounts:
		print(i)

	#print the doc string of the method and class
	print(account1.__doc__)

	#shows the full details of the class - IMPORTANT
	help(SavingsBankAccount)

	#help(SavingsBankAccount.compute_interest)
	print(account1.compute_interest.__doc__)
	
	#calling the object itself - because the class is now callable
	account1()
	account1()
	print(callable(SavingsBankAccount))


if __name__ == '__main__':
	mymain()
