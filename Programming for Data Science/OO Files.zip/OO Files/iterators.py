r = range(3)
r_iter1 = iter(r)
print(next(r_iter1))
print('------------------1----------------')
i = 0
try:
	while(True):
		next(r_iter1)
		i +=1
except:
	print(f'End reached {i}')
print('------------------2----------------')
r_iter2 = iter(r)
print(next(r_iter2))
print('------------------3----------------')
dict1 = zip(range(12),('a','b','c')*3)
d_iter = iter(dict1)
print(next(d_iter))
print(next(d_iter))
print('------------------4----------------')
r = range(5)
r_iter3 = iter(r)
i = 0
while(True):
	try:
		next(r_iter3)
		i +=1
	except StopIteration:
		print(f'End reached {i}')
		break
print('------------------5----------------')

for i in range(5):
	print(i)       #iter object implicitly retrieved and next called till end of the series
print('------------------6----------------')
for line in open('iterators.py'):
	print(line.rstrip())
print('------------------7----------------')
f = open('iterators.py')
for i in range(5):
	print('line: ',next(f).rstrip())

print('------------------8----------------')
#===============================================

# class supporting single iterator
class MyIterableClass:
	def __init__(self,value):
		self._value = value
		self._index = 0
	def __iter__(self):
		return self
	def __next__(self):
		if self._index == len(self._value):
			raise StopIteration
		self._index += 2
		return self._value[self._index-2]

mic1 = MyIterableClass("this is a string")
for i in mic1:
	print('char:', i)

print('------------------9----------------')
# the iterator is exhausted and will not fetch anymore until you get a new iterator object
for i in mic1:
	print('char:', i)
print('------------------10----------------')
mic2 = MyIterableClass("this is a very very long string")
for i in range(7):
	print('char:', next(mic2))
print('------------------11----------------')
# continues where the previous left
for i in range(7):
	print('char:', next(mic2))
print('------------------12----------------')

# class supporting mutliple iterators
# separate itertor class implements __next__ i.e. it keeps track of the iteration
# and the iterable class implements __iter__ i.e. it provides the iterator object
#
class MyIteratorClass:
	def __init__(self,value):
		self._value = value
		self._index = 0
	def __next__(self):
		if self._index == len(self._value):
			raise StopIteration
		else:
			this = self._value[self._index]
			self._index += 2
			return this
	
class MyMultiIteratorIterableClass:
	def __init__(self,value):
		self._value = value
	def __iter__(self):
		return MyIteratorClass(self._value)


mic3 = MyMultiIteratorIterableClass("this is a very very long string")
iter1 = iter(mic3)
iter2 = iter(mic3)
for i in range(5):
	print(next(iter1))
print('------------------13----------------')
for i in range(5):
	print(next(iter2))
print('------------------14----------------')
for i in range(3):
	print(next(iter1))
print('------------------15----------------')
for i in range(5):
	print(next(iter2))
print('------------------16----------------')
for i in range(5):
	print(next(iter1))
