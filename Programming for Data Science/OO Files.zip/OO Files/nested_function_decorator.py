"this module demonstrates the use of decorators - nested function"

#simple decorator - example 1
def my_decorator(f):
	"simple decorator"
	def inner_one(*args):
		print("Inside decorator:: before my_function call")
		f(*args)
		print("Inside decorator:: after my_function call")
	return inner_one

@my_decorator
def my_function():
	print("Inside my_function")

my_function()

print('---------------1---------------')


####################

#simple decorator - example 2
def my_deco1(f):
	"simple decorator"
	def func_inner(l):
		return f(l[0],l[-1])
	return func_inner

@my_deco1	
def my_sum(a,b):
	return 2*a + b

print(my_sum([1,2,3,4]))

print('---------------2---------------')

####################

#adding decorator arguments - example 1
def my_deco2(x):
	"decorator with arguments"
	def my_deco1(f):	
		def func_inner(l):
			return float(f(l[0],l[-1]))/x
		return func_inner
	return my_deco1

@my_deco2(100)
def my_sum(a,b):
	return 2*a + b

print(my_sum([1,2,3,4]))

print('---------------3---------------')

####################

#simple decorator - example 3
def my_deco1(f):
	"simple decorator with retention of state across execution"
	a = 0
	def func_inner(l):
		nonlocal a    # notice the use of nonlocal flag
		a += 1
		print(f'the number of runs of this decorated function so far: {a}')
		return f(l[0],l[-1])	
	return func_inner

@my_deco1	
def my_sum(a,b):
	return 2*a + b

for i in range(4):
	print(my_sum([1,2,3,4]))



	