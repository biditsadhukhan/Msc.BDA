'''
this module demonstrates the use of callable class - version 1
'''

class MyCallableClass:
	'''
	this class implements the __call__ method to become callable
	'''

	def __init__(self, func):
		"initializes the function it is going to decorate"
		self._a = 0
		self._func = func
		print('initialising object')

	def __call__(self, *args, **kwargs):
		r = self._func(*args,**kwargs)
		self._a += r
		print(f'accumulated value so far: {self._a}')


@MyCallableClass
def funcToBeDecorated(x,y,c=10):
	return x ** y + c
	
if __name__ == '__main__':
	for i in range(4):
		funcToBeDecorated(i,2)
	print('---------------------------')
	for i in range(4):
		funcToBeDecorated(i,2,1)
