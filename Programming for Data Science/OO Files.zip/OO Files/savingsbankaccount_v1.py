#import the bankaccount.py module to access the base class definitions
import bankaccount as ba

class SavingsBankAccount(ba.BankAccount):
	"""sub class for savings bank accounts with an empty body and no constructor method which still works - version 1"""


if __name__ == '__main__':
	accounts = []
	account1 = SavingsBankAccount(1000,'rajeev',200)
	account2 = SavingsBankAccount(1001,'sanjeev',100)
	accounts.append(account1)
	accounts.append(account2)
	for i in accounts:
		print("name %s account no. %d balance %d" % (i.get_name(), i._account_no, i.get_initial_balance()))

	