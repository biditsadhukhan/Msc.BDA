#import the bankaccount.py module to access the base class definitions
import bankaccount as ba

class SavingsBankAccount(ba.BankAccount):
	"""
	sub class for savings bank accounts with a constructor which refers to the 
	base class constructor which is delegated the initialization duty - version 3

	"""

	"""method to initialize the object with a custom initial state"""
	def __init__(self, account_no, name, initial_balance):
		"""
		create a new bank account
		
		The initial balance is not zero.

		account_no	a unique identifier of the account (e.g. 1000)
		name		the name of the customer in format <firstname lastname>
		intial_balance	starting amount in the account
		"""
		
		#instance variables given below unique to each instance
		#self._account_no = account_no
		#self._name = name
		#self._initial_balance = initial_balance
		#self._transactions = []
		#self._transactions.append(f"account initialized with amount: {initial_balance}") 
		#self._index = 0
		
		super().__init__(account_no,name,initial_balance)

if __name__ == '__main__':
	accounts = []
	account1 = SavingsBankAccount(1000,'rajeev',200)
	account2 = SavingsBankAccount(1001,'sanjeev',100)
	accounts.append(account1)
	accounts.append(account2)
	for i in accounts:
		print("name %s account no. %d balance %d" % (i.get_name(), i._account_no, i.get_initial_balance()))

	#invoking the __str__ method of the object
	for i in accounts:
		print(i)

	#invoking the __iter__ and __next__ methods of the object
	for j in account1:
		print(j)
