#class starts here>>>>>###
class BankAccount:
	"""Base class for all types of bank accounts"""

	account_type = 'general'	#class variable shared by all instances

	"""method to initialize the object with a custom initial state"""
	def __init__(self, account_no, name, initial_balance):
		"""create a new bank account
		
		The initial balance is not zero.

		account_no	a unique identifier of the account (e.g. 1000)
		name		the name of the customer in format <firstname lastname>
		intial_balance	starting amount in the account
		"""
		#instance variables given below unique to each instance
		self._account_no = account_no
		self._name = name
		self._initial_balance = initial_balance
		self._transactions = []
		self._transactions.append(f"account initialized with amount: {initial_balance}") 
		self._index = 0

	def get_name(self):
		"""return name of the customer"""
		return self._name

	def get_account_no(self):
		"""return account no of the customer"""
		return self._account_no
	
	def get_initial_balance(self):
		"""return initial balance of the customer"""
		return self._initial_balance

	def set_initial_balance(self, initial_balance):
		self._intial_balance = intial_balance
		self._transactions.append(f"account initialized with amount: {initial_balance}") 

	def credit_amount(self, amount):
		self._initial_balance += amount
		self._transactions.append(f"account credited with amount: {amount}") 

	def debit_amount(self, amount):
		self._initial_balance -= amount
		self._transactions.append(f"account debited with amount: {amount}") 

	def transfer_amount(self,account,amount):
		self.debit_amount(amount)
		account.credit_amount(amount)
		self._transactions.append(f"account transfer to another account of amount: {amount}") 

	def __str__(self):
		return "name {} account no. {} balance {}".format(self.get_name(), self._account_no, self.get_initial_balance())

	def __iter__(self):
		return self

	def __next__(self):
		if self._index == len(self._transactions):
			raise StopIteration
		self._index += 1
		return self._transactions[self._index-1]

#the class block finishes here
#external calling code starts below

if __name__ == '__main__':
	x = 10
	accounts = []
	account1 = BankAccount(1000,'rajeev',200)
	account2 = BankAccount(1001,'sanjeev',100)
	accounts.append(account1)
	accounts.append(account2)
	for i in accounts:
		print("name %s account no. %d balance %d" % (i.get_name(), i._account_no, i.get_initial_balance()))
	for i in accounts:
		print(i)
	#a function object is assigned to f as obj.func_name format is the attribute format
	#and all the functions of a class are the attributes of the class
	#below we are not executing the credit_amount method but storing it with an alias for future use
	f = accounts[0].credit_amount
	#below will that f is a method 
	print(type(f)) 
	
	#notice only one argument is passed to the method credit_amount (actually the first argument is the
	#object itself and auto supplied by python
	f(10)
	for i in accounts:
		print(i)
	
	#any data attribute could be created, assigned and deleted from an object - they are instance variables
	account1.x = 10000
	print(account1.x)
	del account1.x
	#trying to retrieve the attribute x after deleting will give error
	#print(account1.x)
	
	#accessing the class variable (data attribute) through the object or directly through the class
	print(account1.account_type)
	print(BankAccount.account_type)
	
	#to access instance variable (data attribute) use the object (instance) and cannot be directly through the class
	print(account1._account_no)
	print(account1.get_account_no())
	#and hence below will give an AttributeError
	#print(BankAccount._account_no)
	
	#print the class of the object instance
	print(account1.__class__)
	print("------------------1-------------------")
	#print the doc string of the class
	print(BankAccount.__doc__)
	print(account1.__doc__)
	print("------------------2-------------------")
	#notice in the transfer_amount method it refers to another method of the same class using self 
	#(optional to use the self)
	account1.transfer_amount(account2,50)
	
	#invoking the __str__ method of the object
	for i in accounts:
		print(i)
	print("------------------3-------------------")
	#invoking the __iter__ and __next__ methods of the object
	for j in account1:
		print(j)




	
