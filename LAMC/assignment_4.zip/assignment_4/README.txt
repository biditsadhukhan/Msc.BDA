AUTHOR: Soumitra Samanta (soumitra.samanta@gm.rkmvu.ac.in)
-----------------------------------------------------------------------------
Please open the "assignment_4_matrix_computation_exc.ipynb" file in your jupyter notebook and follow the notebook instructions.
-----------------------------------------------------------------------------
For query use the above email-id

Enjoy!
